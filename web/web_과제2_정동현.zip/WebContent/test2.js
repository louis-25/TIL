/**
 * 
 */
function popup(){
	alert("AI기술 사이트로 이동하시겠습니까?");
}