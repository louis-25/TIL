package com.multi.ttstest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestTtsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestTtsApplication.class, args);
	}

}
