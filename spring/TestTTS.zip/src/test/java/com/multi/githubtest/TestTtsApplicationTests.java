package com.multi.githubtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestTtsApplicationTests {

	@Test
	void contextLoads() {
	}

}
