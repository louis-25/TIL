package com.multi.teststt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestSttApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestSttApplication.class, args);
	}

}
