select * from c_emp;
select * from c_dept;

